export { default } from './ParallaxLayer';
