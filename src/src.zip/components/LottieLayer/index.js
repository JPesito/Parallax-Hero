export { default } from './LottieLayer';
